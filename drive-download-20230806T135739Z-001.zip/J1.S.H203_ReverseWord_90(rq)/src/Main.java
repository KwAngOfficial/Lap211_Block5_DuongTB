
import java.util.Scanner;

public class Main {

    public static String reverse(String input) {
        String reverse = "";
        String[] words = input.split("\\s+");
        for (int i = words.length - 1; i >= 0; i--) {
            reverse += words[i] + " ";
        }
        reverse = reverse.substring(0);
        return reverse.trim();
    }

    public static String inputString(Scanner SC) {
        do {
            System.out.print("Please enter a string: ");
            String input = SC.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            } else {
                //show error mess if user enter empty sring
                System.err.println("Please enter a non-empty string!");
            }
        } while (true);
    }

    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String input = inputString(SC);
        System.out.println(reverse(input));
    }
}
