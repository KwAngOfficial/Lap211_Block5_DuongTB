

public class Main {
    
    public static String printSquare(int min, int max) {
        if (min > max) {
            return "";
        }
        int distance = max - min;

        StringBuffer sequence = new StringBuffer("");
        String rs = "";

        System.out.println("printSquare(" + min + "," + max + ")");

        while (min <= max) {
            sequence.append(min++);
        }
        
        for (int i = 0; i <= distance; i++) {
            rs += sequence.substring(i, distance+1)+sequence.substring(0,i) + "\n";
        }
        return rs;
    }

    public static void main(String[] args) {
        System.out.println(printSquare(0, 9));
        System.out.println(printSquare(3, 5));
        System.out.println(printSquare(7, 7));
        System.out.println(printSquare(8, 6));
    }
}
